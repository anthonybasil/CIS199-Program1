﻿// Grading ID: R3032
// Program 1
// Due: 9.22.20
// CIS 199-01
// This program takes input (the max width of a room,
// the max length of a room, the price per square yard of hardwood,
// whether underlayment is needed, and whether it is the first room)
// and turns it into output providing an itemzied receipt.

using System;
using static System.Console;

namespace Program1
{
    class Program
    {
        static void Main(string[] args)
        {
            double maxWidth, // defines the maxWidth variable
                   maxLength, // defines the maxLength variable
                   pricePerSqYd; // defines the pricePerSqYd variable
            int underlayment, // defines the underlayment variable
                firstRoom; // defines the firstRoom variable 
                   
            Write("Enter the max width of room (in feet): ");
            maxWidth = double.Parse(ReadLine()); // takes above text and converts to double, assigns value to maxWidth
            Write("Enter the max length of room (in feet): ");
            maxLength = double.Parse(ReadLine()); // takes above text and converts to double, assigns value to maxLength
            Write("Enter the hardwood price (per sq. yard): ");
            pricePerSqYd = double.Parse(ReadLine()); // takes above text and converts to double, assigns value to pricePerSqYd
            Write("Is underlayment needed? (1 = YES, 0 = NO): ");
            underlayment = int.Parse(ReadLine()); // takes above text and converts to integer, assigns value to underlayment
            Write("Is this the first room? (1 = Yes, 0 = NO): ");
            firstRoom = int.Parse(ReadLine()); // takes above text and converts to integer, assigns value to firstRoom

            const double CONVERT = 9; // defines the CONVERT constant
            double squareYardNeed = (maxWidth * maxLength) / CONVERT; // defines the squarYardNeed double with arithemtic
            const double WASTE = 1.1; // defines the WASTE constant
            double hardwoodCost = (squareYardNeed * pricePerSqYd) * WASTE; // defines the hardwoodCost double with arithmetic
            const double UNDERLAY = 4.25; // defines the UNDERLAY constant
            double underlaymentCost; // defines the underlaymentCost double
            double firstRoomCost; // defines the firstRoomCost double
            const int YES = 1; // defines the YES constant
            if (underlayment == YES) // begins if statement for integer underlayment
                underlaymentCost = squareYardNeed * UNDERLAY; // defines underlaymentCost double for if statement with arithmetic
            else
                underlaymentCost = 0; // defines the other half of underlaymentCost double for if statement
            if (firstRoom == YES) // begins if statment for integer firstRoom
                firstRoomCost = 50; // defines firstRoomCost double for if statement
            else
                firstRoomCost = 0; // defines the other half of firstRoomCost for if statement
            const double LABOR = 3.25; // defines the LABOR constant
            double laborCost = LABOR * squareYardNeed + firstRoomCost; // defines the laborCost double with arithmetic
            double totalCost = hardwoodCost + underlaymentCost + laborCost; // defines the totalCost double with arithemetic

            WriteLine(" "); // inserts blank line
            WriteLine($"Sq. Yards Needed: {squareYardNeed:F1}"); // displays how many square yards
            WriteLine($"Hardwood Cost: {hardwoodCost:C2}"); // displays hardwood cost
            WriteLine($"Underlayment Cost: {underlaymentCost:C2}"); // displays underlayment cost, if any
            WriteLine($"Labor Cost: {laborCost:C2}"); // displays labor cost
            WriteLine($"Total Cost: {totalCost:C2}"); // displays total cost
        }
    }
}
